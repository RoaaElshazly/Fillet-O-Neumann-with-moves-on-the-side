package exceptions;

public class ImmediateTooLargeException extends Exception{

	public ImmediateTooLargeException() {
		super();
	}

	public ImmediateTooLargeException(String s) {
		super(s);
	}
}
