package exceptions;

public class AddressOutOfRangeException extends Exception{

	public AddressOutOfRangeException() {
		super();
	}

	public AddressOutOfRangeException(String s) {
		super(s);
	}

}
