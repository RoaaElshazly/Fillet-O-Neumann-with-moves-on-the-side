package exceptions;

public class InvalidRegisterException extends Exception{

	public InvalidRegisterException() {
		super();
	}

	public InvalidRegisterException(String s) {
		super(s);
	}

}
